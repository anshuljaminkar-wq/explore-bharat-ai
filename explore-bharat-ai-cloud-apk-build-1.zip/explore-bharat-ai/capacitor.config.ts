import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.explorebharat.ai',
  appName: 'Explore Bharat AI',
  webDir: 'dist',
  bundledWebRuntime: false
};

export default config;
